/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
public abstract class Pembayaran implements hargaTotal{
    KeranjangBelanja cart;
    Pengiriman pengiriman;
    
   protected String metodePembayaran;

    public Pembayaran(String metodePembayaran) {
        this.metodePembayaran = metodePembayaran;
    }
    public abstract void strukPembayaran();
}
