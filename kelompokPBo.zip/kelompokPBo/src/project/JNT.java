/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
public class JNT extends Pengiriman{
     public JNT(int estimasi) {
        super("JNT", estimasi);
    }
    
    public double ongkirTotal() {
        // Logika perhitungan ongkir JNT berdasarkan estimasi
        if (estimasi==1) {
            hargaOngkir = 18000;
        } else if (estimasi==2) {
            hargaOngkir = 12000;
        }
        return hargaOngkir;
    }
}

