package project;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class TokoPakaian {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        KeranjangBelanja cart = new KeranjangBelanja(20);
        Pengiriman pengiriman = null;
        Pakaian[] pria = new Pakaian[20];
        Pakaian[] wanita = new Pakaian[20];
        Pakaian[] anakAnak = new Pakaian[20];
        int pilihan = 0;
        int pilihKurir = 0;
        int pilihKategori = 0;
        
        int pilihPembayaran = 0;
        int jenis = 0;
        System.out.println("===================================================================================");
        System.out.println("                           WELCOME TO ONLINE SHOP LIMITED EDITION                       ");
        System.out.println("===================================================================================");
        System.out.println();
        boolean selesai = false;
       do {
    System.out.println("Menu:");
    System.out.println("1. Tambah Pakaian");
    System.out.println("2. Hapus Pakaian");
    System.out.println("3. Lihat Keranjang");
    System.out.println("4. Selesai dan Bayar");
    System.out.println("================-");
    
    try {
        pilihan = getInputInt("Pilihan anda: ");
    } catch (InputMismatchException e) {
        System.out.println("Input tidak valid, silakan coba lagi.");
        
        continue;
    }
    
    System.out.println();
    
    switch (pilihan) {
        case 1:
            // Tambah pakaian
            boolean tambahPakaian = true;
            do {
                System.out.println("Pilih kategori:");
                System.out.println("1. Pria ");
                System.out.println("2. Wanita ");
                System.out.println("3. Anak anak");
                System.out.println("---------------");

                try {
                    pilihKategori = getInputInt("Pilihan anda : ");
                } catch (InputMismatchException e) {
                    System.out.println("Input tidak valid, silakan coba lagi.");
                    
                    continue;
                }

                if (pilihKategori == 1) {
                    do {
                        System.out.println("Pilih Jenis:");
                        System.out.println("1. Baju ");
                        System.out.println("2. Celana ");
                        System.out.println("3. Jaket ");
                        System.out.println("----------");

                        try {
                            jenis = getInputInt("Jenis pakaian yang ingin dibeli : ");
                        } catch (InputMismatchException e) {
                            System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                            continue;
                        }

                        if (jenis == 1) {
                            pria[cart.jumlah] = new Pakaian("Baju");
                            pria[cart.jumlah].daftarBajuPria();
                            cart.tambahPakaian(pria[cart.jumlah]);
                            cart.jumlah++;
                        } else if (jenis == 2) {
                            pria[cart.jumlah] = new Pakaian("Celana");
                            pria[cart.jumlah].daftarCelanaPria();
                            cart.tambahPakaian(pria[cart.jumlah]);
                            cart.jumlah++;
                        } else if (jenis == 3) {
                            pria[cart.jumlah] = new Pakaian("Jaket");
                            pria[cart.jumlah].daftarJaketPria();
                            cart.tambahPakaian(pria[cart.jumlah]);
                            cart.jumlah++;
                        } else {
                            System.out.println("Pilihan tidak tersedia, coba lagi");
                        }
                    } while (jenis <= 0 || jenis > 3);

                } else if (pilihKategori == 2) {
                    do {
                        System.out.println("------------- Pilih Jenis --------------");
                        System.out.println("1. Baju ");
                        System.out.println("2. Celana ");
                        System.out.println("3. Jaket ");
                        System.out.println("4. Rok");
                        System.out.println("----------------------------------------");

                        try {
                            jenis = getInputInt("Jenis pakaian yang ingin dibeli : ");
                        } catch (InputMismatchException e) {
                            System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                            continue;
                        }

                        if (jenis == 1) {
                            wanita[cart.jumlah] = new Pakaian("Baju");
                            wanita[cart.jumlah].daftarBajuWanita();
                            cart.tambahPakaian(wanita[cart.jumlah]);
                        } else if (jenis == 2) {
                            wanita[cart.jumlah] = new Pakaian("Celana");
                            wanita[cart.jumlah].daftarCelanaWanita();
                            cart.tambahPakaian(wanita[cart.jumlah]);
                        } else if (jenis == 3) {
                            wanita[cart.jumlah] = new Pakaian("Jaket");
                            wanita[cart.jumlah].daftarJaketWanita();
                            cart.tambahPakaian(wanita[cart.jumlah]);
                        } else if (jenis == 4) {
                            wanita[cart.jumlah] = new Pakaian("Rok");
                            wanita[cart.jumlah].daftarRokWanita();
                            cart.tambahPakaian(wanita[cart.jumlah]);
                        }

                    } while (jenis <= 0 || jenis > 4);

                } else if (pilihKategori == 3) {
                    do {
                        System.out.println("Pilih Jenis:");
                        System.out.println("1. Baju ");
                        System.out.println("2. Celana ");
                        System.out.println("3. Jaket ");
                        System.out.println("-------------------------------");

                        try {
                            jenis = getInputInt("Jenis pakaian yang ingin dibeli : ");
                        } catch (InputMismatchException e) {
                            System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                            continue;
                        }

                        if (jenis == 1) {
                            anakAnak[cart.jumlah] = new Pakaian("Baju");
                            anakAnak[cart.jumlah].daftarBajuAnakAnak();
                            cart.tambahPakaian(anakAnak[cart.jumlah]);
                        } else if (jenis == 2) {
                            anakAnak[cart.jumlah] = new Pakaian("Celana");
                            anakAnak[cart.jumlah].daftarCelanaAnakAnak();
                            cart.tambahPakaian(anakAnak[cart.jumlah]);
                        } else if (jenis == 3) {
                            anakAnak[cart.jumlah] = new Pakaian("Jaket");
                            anakAnak[cart.jumlah].daftarJaketAnakAnak();
                            cart.tambahPakaian(anakAnak[cart.jumlah]);
                        } else {
                            System.out.println("Pilihan tidak tersedia, silakan coba lagi.");
                        }

                    } while (jenis <= 0 || jenis > 3);
                }
            } while (pilihKategori <= 0 || pilihKategori >= 4);

            break;
    

                    case 2:
                        // Hapus pakaian
                         int nomorHapus = 0 ;
                        cart.tampilkanPakaian();
                         if (cart.jumlah == 0)
                        {
                            System.out.println("Keranjang belanja kosong. Tidak dapat melanjutkan proses.");
                        } else
                        {
                           
                        System.out.println("Masukkan nomor pakaian yang ingin dihapus:");
                        try{
                        nomorHapus = getInputInt("Nomor pakaian: ");
                        } catch (InputMismatchException e)
                            {
                                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                                
                            }
                        cart.hapusPakaian(nomorHapus);
                        break;
                        
                            }

                    case 3:
                        // Lihat keranjang
                        System.out.println("=======================================");
                        cart.tampilkanPakaian();
                        break;
                    case 4:
                        // Selesai dan bayar
                         if (cart.jumlah == 0)
                        {
                            System.out.println("Keranjang belanja kosong. Tidak dapat melanjutkan proses.");
                        } else
                        {
                            do{
                        System.out.println("=================== Pengiriman ========================");
                        cart.tampilkanPakaian();
                        System.out.println("Pilih Kurir Pengiriman = ");
                        System.out.println("1. JNE ");
                        System.out.println("2. JNT ");
                        System.out.println("3. SiCepat ");
                        try{
                        pilihKurir = TokoPakaian.getInputInt("Pilihan anda: ");
                          } catch (InputMismatchException e)
                            {
                                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                                
                            }
                     
                            if (pilihKurir == 1)
                            {
                                System.out.println("1. 1 hari sampai ");
                                System.out.println("2. 3/4 hari sampai ");
                                int estimasi = TokoPakaian.getInputInt("Estimasi anda: ");
                                pengiriman = new JNE(estimasi);

                            } else if (pilihKurir == 2)
                            {
                                System.out.println("1. 1 hari sampai ");
                                System.out.println("2. 3/4 hari sampai ");
                                int estimasi = TokoPakaian.getInputInt("Estimasi anda: ");
                                pengiriman = new JNT(estimasi);

                            } else if (pilihKurir == 3)
                            {
                                System.out.println("1. 1 hari sampai ");
                                System.out.println("2. 3/4 hari sampai ");
                                int estimasi = TokoPakaian.getInputInt("Estimasi anda: ");
                                pengiriman = new SiCepat(estimasi);
                            }
                            }while(pilihKurir<=0 || pilihKurir>3);
                             if (cart.jumlah == 0)
                            {
                                System.out.println("Keranjang belanja kosong. Tidak dapat melakukan pembayaran ");
                            } else
                            {
                                do{
                            System.out.println("=============== Pembayaran ===============");
                            System.out.println("Pilih jenis Pembayaran = ");
                            System.out.println("1. Debit ");
                            System.out.println("2. COD(Cash on delivery) ");
                            System.out.println("3. Alfamart/Indomart ");
                            try{
                            pilihPembayaran = TokoPakaian.getInputInt("Pilihan anda: ");
                             } catch (InputMismatchException e)
                            {
                                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                                
                            }
                                if (pilihPembayaran == 1)
                                {
                                    Debit debit = null;
                                    System.out.println("1. BCA ");
                                    System.out.println("2. Mandiri ");
                                    System.out.println("3. BRI ");
                                    System.out.println("4. BNI ");
                                    int namaBank = TokoPakaian.getInputInt("Pilih bank : ");
                                    if (namaBank == 1)
                                    {
                                        String nomorRekening = TokoPakaian.getInputString("Nomor rekening : ");
                                        debit = new Debit(nomorRekening, cart, pengiriman);
                                        debit.setNamaBank("BCA");
                                    } else if (namaBank == 2)
                                    {
                                        String nomorRekening = TokoPakaian.getInputString("Nomor rekening : ");
                                        debit = new Debit(nomorRekening, cart, pengiriman);
                                        debit.setNamaBank("Mandiri");
                                    } else if (namaBank == 3)
                                    {
                                        String nomorRekening = TokoPakaian.getInputString("Nomor rekening : ");
                                        debit = new Debit(nomorRekening, cart, pengiriman);
                                        debit.setNamaBank("BRI");
                                    } else if (namaBank == 4)
                                    {
                                        String nomorRekening = TokoPakaian.getInputString("Nomor rekening : ");
                                        debit = new Debit(nomorRekening, cart, pengiriman);
                                        debit.setNamaBank("BNI");
                                    } else
                                    {
                                        System.out.println("Input tidak valid");
                                    }

                                    if (debit != null)
                                    {
                                        debit.strukPembayaran();
                                        
                                    }
                                }
                                   
                                else if (pilihPembayaran == 2)
                                {
                                    CashOnDelivery COD = new CashOnDelivery(cart, pengiriman);
                                    COD.strukPembayaran();
                                } else if (pilihPembayaran == 3)
                                {
                                    String nomorStruk = TokoPakaian.getInputString("Nomor Struk : ");
                                    Alfamart_Indomart alfaindo = new Alfamart_Indomart(nomorStruk, cart, pengiriman);
                                    System.out.println("harga total yang harus di bayarkan = " + alfaindo.hargaTotal());
                                    alfaindo.strukPembayaran();
                                }
                            }while(pilihPembayaran<=0 || pilihPembayaran>3);
                                }

                            selesai = true; // Keluar dari loop utama
                        }
                        break;
                    default:
                        System.out.println("Pilihan tidak tersedia, silakan coba lagi.");
                        break;
                }
        
        }while(!selesai);
    }

    public static String getInputString(String message) {
        Scanner input = new Scanner(System.in);
        System.out.print(message);
        String data = input.nextLine();
        return data;
    }

    public static double getInputDouble(String message) {
        Scanner input = new Scanner(System.in);
        System.out.print(message);
        double data = input.nextDouble();
        return data;
    }

    public static int getInputInt(String message) {
        Scanner input = new Scanner(System.in);
        System.out.print(message);
        int data = input.nextInt();
        return data;
    }
}
