/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
public class Debit extends Pembayaran {
    private String nomorKartu;
    private String namaBank;
    private double diskon = 0;
    
    public Debit(String nomorKartu, KeranjangBelanja cart, Pengiriman pengiriman) {
        super("Debit");
        this.nomorKartu = nomorKartu;
        this.cart = cart;
        this.pengiriman = pengiriman;
        this.diskon=diskon;
    }

    public String getNomorKartu() {
        return nomorKartu;
    }

    public void setNomorKartu(String nomorKartu) {
        this.nomorKartu = nomorKartu;
    }

    public String getNamaBank() {
        return namaBank;
    }

    public void setNamaBank(String namaBank) {
        this.namaBank = namaBank;
    }

    public double getDiskon() {
        return diskon;
    }

    public void setDiskon(double diskon) {
        this.diskon = diskon;
    }

    // Metode hargaTotal() diperbarui dengan penggunaan cart dan pengiriman yang telah dideklarasikan dan diinisialisasi
    public double hargaTotal() {
        double totalHarga = cart.getTotalHarga() + pengiriman.ongkirTotal();

        if (totalHarga >= 500000)
        {
            diskon = totalHarga * 0.10;
        } else if (totalHarga >= 1000000)
        {
            diskon = totalHarga * 0.25;
        } else
        {
            diskon = 0; // Jika tidak memenuhi kondisi diskon, set diskon ke 0
        }

        setDiskon(diskon); // Mengatur nilai diskon
        totalHarga -= diskon;

        return totalHarga;
    }

    @Override
     public void strukPembayaran(){
        System.out.println("================Struk Pembayaran===============");
        System.out.println("Metode pembayaran = "+metodePembayaran);
        System.out.println("Limited Edition ");
        System.out.println("KEC DEPOK KAB SLEMAN, 55282");
        System.out.println("==============================================");
        System.out.println("==============================================");
        cart.tampilkanPakaian();
        double totalHarga = cart.getTotalHarga() + pengiriman.ongkirTotal();
          System.out.println("\t\tTotal harga barang = "+cart.getTotalHarga());
          System.out.println("\t\tongkir = "+pengiriman.ongkirTotal());
          System.out.println("\t\tHarga total = "+totalHarga);
           if (totalHarga >= 500000)
        {
            System.out.println("\t\tDiskon = 10%");
        } else if (totalHarga >= 1000000)
        {
            System.out.println("\t\tDiskon = 25%");
        } else
        {
            
        }
          System.out.println("\t\tTotal bayar= "+hargaTotal());
        
        
    }
}
