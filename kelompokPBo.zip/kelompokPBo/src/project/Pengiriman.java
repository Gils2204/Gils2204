/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
public abstract class Pengiriman implements OngkirTotal{
    protected String kurirPengiriman;
    protected int estimasi;
    protected double hargaOngkir;
    

    public Pengiriman(String kurirPengiriman, int estimasi) {
        this.kurirPengiriman = kurirPengiriman;
        this.estimasi = estimasi;
    }
    
}

