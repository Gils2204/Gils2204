/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
public class KeranjangBelanja {
    public Pakaian[] pakaian;
    public int jumlah;

    public KeranjangBelanja(int ukuran) {
        pakaian = new Pakaian[ukuran];
        jumlah = 0;
    }
    

    public void tambahPakaian(Pakaian pakaian) {
        if (jumlah < this.pakaian.length) {
            this.pakaian[jumlah] = pakaian;
            jumlah++;
            System.out.println("Pakaian ditambahkan ke keranjang: " + pakaian.jenisPakaian);
        } else {
            System.out.println("Keranjang sudah penuh. Tidak dapat menambahkan pakaian lebih banyak.");
        }
    }

    public void hapusPakaian(int indeks) {
        indeks -= 1;
    if (indeks >= 0 && indeks < jumlah) {
        if (pakaian[indeks] != null) {
            System.out.println("Pakaian dihapus dari keranjang: " + pakaian[indeks].getJenisPakaian());
            for (int i = indeks; i < jumlah - 1; i++) {
                pakaian[i] = pakaian[i + 1];
            }
            pakaian[jumlah - 1] = null;
            jumlah--;

            // Perbarui daftar pakaian setelah penghapusan
            tampilkanPakaian();
        } else {
            System.out.println("Pakaian tidak valid.");
        }
    } else {
        System.out.println("Indeks tidak valid.");
    }
}




    public void tampilkanPakaian() {
    if (jumlah == 0) {
        System.out.println("Keranjang kosong.");
    } else {
        System.out.println("Pakaian dalam keranjang:");
        for (int i = 0; i < jumlah; i++) {
            if (pakaian[i] != null) {
                System.out.println((i + 1) + ". " + pakaian[i].getJenisPakaian() + "   " + pakaian[i].getNamaPakaian() + ", Harga: Rp" + pakaian[i].getHarga());
            }
        }
    }
}



    public double getTotalHarga() {
    double totalHarga = 0;
    for (int i = 0; i < jumlah; i++) {
        if (pakaian[i] != null) {
            totalHarga += pakaian[i].getHarga();
        }
    }
    return totalHarga;
}

}

