
package project;

//Michael Diva Berliano (225314020)
//Michael Jerry Thomas (225314027)
//Ni made ayu sukmawarnadi (225314021)
//Ni luh chandrawali (225314012)
//Fortuna Ratna Dewi (225314025)
//Joseph Gilang Dhika Candra (225314013)

public class Mahasiswa {
    String nama;
    String nim;
    String email;
    int umur;
    
    public Mahasiswa(String nama, String nim){
        this.nama = nama;
        this.nim = nim;
    }
    
    public void setEmail(String email){
        this.email = email;
    }
    
    public void setUmur(int umur){
        this.umur = umur;
    }
    
    public String getNama(){
        return nama;
    }
    
    public String getNim(){
        return nim;
    }
    
    public String getEmail(){
        return email;
    }
    
    public int getUmur(){
        return umur;
    }
}
