/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
public class SiCepat extends Pengiriman{
     public SiCepat(int estimasi) {
        super("Si Cepat", estimasi);
    }

    public double ongkirTotal() {
        // Logika perhitungan ongkir Si Cepat berdasarkan estimasi
        if (estimasi == 1) {
            hargaOngkir = 20000;
        } else if (estimasi == 2) {
            hargaOngkir = 15000;
        }
        return hargaOngkir;
    }
}
