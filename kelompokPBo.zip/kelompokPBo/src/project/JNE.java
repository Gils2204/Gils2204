/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
public class JNE extends Pengiriman{
    public JNE(int estimasi) {
        super("JNE", estimasi);
    }

    @Override
    public double ongkirTotal() {
        // Logika perhitungan ongkir JNE berdasarkan estimasi
        if (estimasi == 1) {
            hargaOngkir = 15000;
        } else if (estimasi == 1) {
            hargaOngkir = 10000;
        }
        return hargaOngkir;
    }
}
