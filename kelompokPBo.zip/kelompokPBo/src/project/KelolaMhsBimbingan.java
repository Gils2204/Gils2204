package project;

import java.util.Scanner;
import project.Dosen;
import project.Mahasiswa;
//Michael Diva Berliano (225314020)
//Michael Jerry Thomas (225314027)
//Ni made ayu sukmawarnadi (225314021)
//Ni luh chandrawali (225314012)
//Fortuna Ratna Dewi (225314025)
//Joseph Gilang Dhika Candra (225314013)

public class KelolaMhsBimbingan {

    public static void main(String[] args) {
        
        Mahasiswa[] mhs;
        String nim, nama, email;
        int umur;
        mhs = new Mahasiswa[5]; 
        Scanner input = new Scanner(System.in);
        
        for (int i = 0; i <4; i++) {
            System.out.println("Masukkan data mahasiswa ke- "+(i+1));
            System.out.print("NIM\t: ");
            nim = input.nextLine();
            input.nextLine();
            System.out.print("Nama\t: ");
            nama = input.nextLine();
            System.out.print("Email\t: ");
            email = input.nextLine();
            System.out.print("Umur\t: ");
            umur = input.nextInt();
            mhs[i] = new Mahasiswa(nim, nama);
            mhs[i].setEmail(email);
            mhs[i].setUmur(umur);
        }
        
        Dosen dsn1=new Dosen("67","Agung");
        dsn1.setMahasiswa(mhs);
        
        //menambah 1 orang mahasiswa ke dalam array mahasiswa di objek dosen dsn1
        Mahasiswa m1 = new Mahasiswa("213114005", "Ani");
        m1.setEmail("ani@gmail.com");
        m1.setUmur(20);
        dsn1.addMahasiswa(4,m1);
        
        //menampilkan isi array mahasiswa yang dibimbing dosen dsn1
        Mahasiswa[] tampung=dsn1.getMahasiswa();
        
        for (int i=0;i<tampung.length;i++){
            System.out.println(tampung[i].getNama());
        }
        
        //memanggil metode cariMahasiswaTermuda yang dimbing dosen dsn1
        Mahasiswa m2 = dsn1.cariMahasiswaTermuda();
        
        //menampilkan data mahasiswa termuda yang dibimbing dosen dsn1.
        System.out.println("Mahasiswa termuda yang dimbing Dosen " + 
        dsn1.getNama() +" adalah :");
        System.out.println("- Nama: " + m2.getNama());
        System.out.println("- NIM: " + m2.getNim());
        System.out.println("- Umur: " + m2.getUmur());
        System.out.println("- Email: " + m2.getEmail()); 
        
        //mencari mahasiswa berdasarkan NIM
        String ketik = input.nextLine();
        Mahasiswa x;
        int n;
        int i = 0;
        
        do {
            n = dsn1.cariMahasiswaNim(ketik, i);
            x = dsn1.getMahasiswa()[n];
            i++;
        } while (i < dsn1.getMahasiswa().length);
        
        if (n == -1) {
            System.out.println("Mahasiswa tidak ditemukan");
        }
        else{
            System.out.println("Mahasiswanya adalah :");
            System.out.println("- Nama: " + x.getNama());
            System.out.println("- NIM: " + x.getNim());
            System.out.println("- Umur: " + x.getUmur());
            System.out.println("- Email: " + x.getEmail()); 
        } 
    }
}
