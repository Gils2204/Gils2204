/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
public class CashOnDelivery extends Pembayaran {
    
    public CashOnDelivery(KeranjangBelanja cart, Pengiriman pengiriman){
        super("Cash on delivery");
        this.cart = cart;
        this.pengiriman = pengiriman;
    }
      public double hargaTotal(){
        double totalHarga = cart.getTotalHarga();
        return totalHarga;
   }
    public void strukPembayaran(){
        System.out.println("================Struk Pembayaran===============");
        System.out.println("Metode pembayaran = "+metodePembayaran);
        System.out.println("Limited Edition ");
        System.out.println("KEC DEPOK KAB SLEMAN, 55282");
        System.out.println("==============================================");
        System.out.println("==============================================");
        cart.tampilkanPakaian();
        
          System.out.println("\t\tHarga = "+cart.getTotalHarga());
          System.out.println("\t\tOngkir = "+pengiriman.ongkirTotal());
          System.out.println("\t\tGratis Ongkir = -"+pengiriman.ongkirTotal());
          System.out.println("\t\tTotal bayar = "+hargaTotal());
        
        
    }
}
