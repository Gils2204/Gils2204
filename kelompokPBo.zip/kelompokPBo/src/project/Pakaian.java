/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;

/**
 *
 * @author Stefanus Saputra
 */
import java.util.InputMismatchException;
import java.util.Scanner;

public class Pakaian {

    Scanner scan = new Scanner(System.in);
    protected String jenisPakaian;
    protected String ukuran;
    protected String jenisPembayaran;
    protected String email;
    protected double harga;
    protected String bahan;
    protected String namaPakaian;
    protected String edisi;
    protected String merk;
    int pilih;
    int size;

    public Pakaian(String jenisPakaian) {
        this.jenisPakaian = jenisPakaian;
    }

    public String getNamaPakaian() {
        return namaPakaian;
    }

    public void setNamaPakaian(String namaPakaian) {
        this.namaPakaian = namaPakaian;
    }

    public String getEdisi() {
        return edisi;
    }

    public void setEdisi(String edisi) {
        this.edisi = edisi;
    }

    public void setBahan(String bahan) {
        this.bahan = bahan;
    }

    public String getBahan() {
        return bahan;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getHarga() {
        return harga;
    }

    public void setHarga(double harga) {
        this.harga = harga;
    }

    public String getJenisPakaian() {
        return jenisPakaian;
    }

    public void setJenisPakaian(String jenisPakaian) {
        this.jenisPakaian = jenisPakaian;
    }

    public String getUkuran() {
        return ukuran;
    }

    public void setUkuran(String ukuran) {
        this.ukuran = ukuran;
    }

    public String getJenisPembayaran() {
        return jenisPembayaran;
    }

    public void setJenisPembayaran(String jenisPembayaran) {
        this.jenisPembayaran = jenisPembayaran;
    }

    public void daftarBajuPria() {
        do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis baju ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tADIDAS\t\tV-neck ");
        System.out.println("2.\t\tH&M\t\tKemeja pendek");
        System.out.println("3.\t\tM&S\t\tkaos");
        System.out.println("4.\t\tPUMA\t\tKemeja panjang");
        System.out.println("================================================");
        System.out.print("Pilih Jenis Baju : ");
            try
            {
                pilih = scan.nextInt();
            } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }

        switch (pilih) {
            case 1:
                setHarga(800000);
                setNamaPakaian("Adidas/V-neck");
                setEdisi("2016");
                setBahan("Chambray");
                ukuranBajuPria();
                break;

            case 2:
                harga = 500000;
                setNamaPakaian("H&M/Kemeja pendek");
                setEdisi("2014");
                setBahan("Oxford");
                ukuranBajuPria();
                break;
            case 3:
                harga = 400000;
                setNamaPakaian("M&S/Kaos");
                setEdisi("2020");
                setBahan("Denim");
                ukuranBajuPria();
                break;
            case 4:
                harga = 350000;
                setNamaPakaian("Puma/Kemeja Panjang");
                setEdisi("2015");
                setBahan("Silk");
                ukuranBajuPria();
                break;
            default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        
    }
        }while(pilih<=0 || pilih>4);
    }

    public void ukuranBajuPria() {
      do{
        System.out.println("================================================");
        System.out.println("No.\tUkuran\tPanjang\t  Lebar   ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\tS\t68 cm\t 50 cm");
        System.out.println("2.\tM\t71 cm\t 53 cm");
        System.out.println("3.\tL\t74 cm\t 56 cm");
        System.out.println("4.\tXL\t77 cm\t 59 cm");
        System.out.println("5.\tXXL\t80 cm\t 62 cm");
        System.out.println("================================================");
        System.out.print("Pilih Ukuran Baju : ");
        try
            {
                size = scan.nextInt();
            } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        System.out.println("================================================");
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 4:
                System.out.println("--------------------------------------------");
                harga = harga + 5000;
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                System.out.println("--------------------------------------------");
                harga = harga + 7000;
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(size<=0 || size>5);
    }

    public void daftarCelanaPria() {
        do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis Celana ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tLevi's\t\tJeans ");
        System.out.println("2.\t\tDiesel\t\tCargo");
        System.out.println("3.\t\tGuess \t\tChino");
        System.out.println("4.\t\tCarvil\t\tJoger");
        System.out.println("================================================");

        System.out.print("Pilih Jenis Celana : ");
        try{
        pilih = scan.nextInt();
            } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (pilih) {
            case 1:
                harga = 400000;
                setNamaPakaian("Levis's\tJeans");
                setEdisi("2021");
                setBahan("Drill");
                ukuranCelanaPria();
                break;

            case 2:
                harga = 500000;
                setNamaPakaian("Diesel\tCargo");
                setEdisi("2019");
                setBahan("Thaisilk");
                ukuranCelanaPria();
                break;
            case 3:
                harga = 350000;
                setNamaPakaian("Guess\tChino");
                setEdisi("2017");
                setBahan("Polyester");
                ukuranCelanaPria();
                break;
            case 4:
                harga = 300000;
                setNamaPakaian("Carvi;\tJoger");
                setEdisi("2018");
                setBahan("Corduroy");
                ukuranCelanaPria();
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(pilih<=0 || pilih>4);
    }

    public void daftarJaketPria() {
        do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis Jaket");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tDeus\t\tBomber ");
        System.out.println("2.\t\tEiger\t\thoodie");
        System.out.println("3.\t\tErigo\t\tDenim");
        System.out.println("4.\t\tzalora\t\tVarsity");
        System.out.println("================================================");

        System.out.print("Pilih Jenis Jaket : ");
        try{
        pilih = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (pilih) {
            case 1:
                harga = 800000;
                setNamaPakaian("Deus\tBomber");
                setEdisi("2022");
                setBahan("Fleece");
                ukuranJaketPria();
                break;

            case 2:
                harga = 500000;
                setNamaPakaian("Eiger\tHoodie");
                setEdisi("2014");
                setBahan("Baby terry");
                ukuranJaketPria();
                break;
            case 3:
                harga = 400000;
                setNamaPakaian("Erigo\tDenim");
                setEdisi("2020");
                setBahan("Drill");
                ukuranJaketPria();
                break;
            case 4:
                harga = 350000;
                setNamaPakaian("Zalora\tVarsity");
                setEdisi("2019");
                setBahan("Taslan");
                ukuranJaketPria();
                break;
        default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(pilih<=0 || pilih>4);
    }

    public void ukuranJaketPria() {
        do{
        System.out.println("==============================================================================================");
        System.out.println("No.\tUkuran\tPanjang jaket\tLebar jaket\tPanjang Tangan\tEstimasi Berat Badan   ");
        System.out.println("----------------------------------------------------------------------------------------------");
        System.out.println("1.\tS\t63 cm\t\t50 cm\t\t56 cm\t\t40-48 kg");
        System.out.println("2.\tM\t66 cm\t\t52 cm\t\t58 cm\t\t48-57 kg");
        System.out.println("3.\tL\t67 cm\t\t54 cm\t\t60 cm\t\t57-67 kg");
        System.out.println("4.\tXL\t69 cm\t\t58 cm\t\t62 cm\t\t67-74 kg");
        System.out.println("5.\tXXL\t70 cm\t\t60 cm\t\t63 cm\t\t74-81 kg");
        System.out.println("===============================================================================================");
        System.out.print("Pilih Ukuran Jaket : ");
        try{
        size = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        System.out.println("===============================================================================================");
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 4:
                harga = harga + 5000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                System.out.println("--------------------------------------------");
                harga = harga + 7000;
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
            }while(size<=0 || size>5);
        
    }

    public void ukuranCelanaPria() {
        do{
        System.out.println("================================================");
        System.out.println("No.\tUkuran\tPinggang\tPanjang kaki   ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\tS\t68 cm\t\t81 cm");
        System.out.println("2.\tM\t70 cm\t\t81 cm");
        System.out.println("3.\tL\t72 cm\t\t82 cm");
        System.out.println("4.\tXL\t74 cm\t\t82 cm");
        System.out.println("5.\tXXL\t80 cm\t\t84 cm");
        System.out.println("================================================");
        System.out.print("Pilih Ukuran Celana : ");
        try{
        size = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        System.out.println("================================================");
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 4:
                System.out.println("--------------------------------------------");
                harga = harga + 7000;
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                System.out.println("--------------------------------------------");
                harga = harga + 10000;
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(size<=0 || size>5);
    }

    public void daftarBajuWanita() {
        do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis baju ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tChannel\t\tCardigan ");
        System.out.println("2.\t\tLevi's\t\tTurtleneck");
        System.out.println("3.\t\tNevada\t\tblazzer");
        System.out.println("4.\t\tUniqlo\t\tKemeja");
        System.out.println("================================================");
        try{
        pilih = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (pilih) {
            case 1:
                setHarga(1200000);
                setNamaPakaian("Channel\tCardigan");
                setEdisi("2020");
                setBahan("Katun");
                ukuranBajuWanita();
                break;

            case 2:
                harga = 850000;
                setNamaPakaian("Levi's\tTurtleneck");
                setEdisi("2021");
                setBahan("Linen");
                ukuranBajuWanita();
                break;
            case 3:
                harga = 385000;
                setNamaPakaian("Nevada\tBlazzer");
                setEdisi("2019");
                setBahan("Denim");
                ukuranBajuWanita();
                break;
            case 4:
                harga = 400000;
                setNamaPakaian("Channel\tCardigan");
                setEdisi("2018");
                setBahan("Drill");
                ukuranBajuWanita();
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(pilih<=0 || pilih>4);
    }

    public void ukuranBajuWanita() {
        do{
        System.out.println("================================================");
        System.out.println("No.\tUkuran\tPanjang\t  Lebar   ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\tS\t40 cm\t 57 cm");
        System.out.println("2.\tM\t42 cm\t 60 cm");
        System.out.println("3.\tL\t45 cm\t 63 cm");
        System.out.println("4.\tXL\t48 cm\t 66 cm");
        System.out.println("5.\tXXL\t50 cm\t 69 cm");
        System.out.println("================================================");
        try{
        size = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");

                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");

                break;
            case 4:
                harga = harga + 7000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                harga = harga + 9000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(size<=0 || size>5);
    }

    public void daftarCelanaWanita() {
        do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis Celana ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tZara\t\tWide Leg pants ");
        System.out.println("2.\t\tCardinal\tStraight pants");
        System.out.println("3.\t\tLoiss \t\tSlacks");
        System.out.println("4.\t\tJiniso \t\tSlimfit jeans");
        System.out.println("================================================");
        try{
        pilih = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
            
        switch (pilih) {
            case 1:
                harga = 175000;
                setNamaPakaian("Zara\tWide Leg Pants");
                setEdisi("2018");
                setBahan("Thaisilk");
                ukuranCelanaWanita();
                break;

            case 2:
                harga = 400000;
                setNamaPakaian("Cardinal\tStraight Pants");
                setEdisi("2021");
                setBahan("Nilon");
                ukuranCelanaWanita();
                break;
            case 3:
                harga = 600000;
                setNamaPakaian("Loiss\tSlacks");
                setEdisi("2022");
                setBahan("Corduroy");
                ukuranCelanaWanita();
                break;
            case 4:
                harga = 300000;
                setNamaPakaian("Jiniso\tSlimfit Jeans");
                setEdisi("2018");
                setBahan("Polyester");
                ukuranCelanaWanita();
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(pilih<=0 || pilih>4);
    }

    public void ukuranCelanaWanita() {
        do{
        System.out.println("================================================");
        System.out.println("No.\tUkuran\tPinggang\tPanjang kaki   ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\tS\t72 cm\t\t79 cm");
        System.out.println("2.\tM\t78 cm\t\t85 cm");
        System.out.println("3.\tL\t82 cm\t\t88 cm");
        System.out.println("4.\tXL\t84 cm\t\t94 cm");
        System.out.println("5.\tXXL\t87 cm\t\t97 cm");
        System.out.println("================================================");
        try{
        size = scan.nextInt();
                } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");

                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");

                break;
            case 4:
                harga = harga + 8000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                harga = harga + 12000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(size<=0 || size>5);
    }

    public void daftarRokWanita() {
       do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis Rok ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tZara\t\tA-Line Skirt");
        System.out.println("2.\t\tUniqlo\t\tMaxi Skirt ");
        System.out.println("3.\t\tLoiss \t\tMicro Skirt");
        System.out.println("4.\t\tJiniso \t\tMidi Skirt ");
        System.out.println("================================================");
        try{
        pilih = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (pilih) {
            case 1:
                harga = 175000;
                setNamaPakaian("Zara\tWide Leg Pants");
                setEdisi("2018");
                setBahan("Thaisilk");
                ukuranCelanaWanita();
                break;

            case 2:
                harga = 400000;
                setNamaPakaian("Unoqlo\tStraight Pants");
                setEdisi("2021");
                setBahan("Nilon");
                ukuranCelanaWanita();
                break;
            case 3:
                harga = 600000;
                setNamaPakaian("Loiss\tSlacks");
                setEdisi("2022");
                setBahan("Corduroy");
                ukuranCelanaWanita();
                break;
            case 4:
                harga = 300000;
                setNamaPakaian("Jiniso\tSlimfit Jeans");
                setEdisi("2018");
                setBahan("Polyester");
                ukuranCelanaWanita();
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
       }while(pilih<=0 || pilih>4);
    }

    public void ukuranRokWanita() {
        do{
        System.out.println("================================================");
        System.out.println("No.\tUkuran\tPinggang\tPanjang kaki   ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\tS\t72 cm\t79 cm");
        System.out.println("2.\tM\t78 cm\t85 cm");
        System.out.println("3.\tL\t82 cm\t88 cm");
        System.out.println("4.\tXL\t84 cm\t94 cm");
        System.out.println("5.\tXXL\t87 cm\t97 cm");
        System.out.println("================================================");
        try{
        size= scan.nextInt();
           } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");

                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");

                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");

                break;
            case 4:
                harga = harga + 8000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                harga = harga + 12000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        
        }
        }while(size<=0 || size>5);
    }
    public void daftarJaketWanita() {
        do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis Jaket");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tDream Birds\tZipper ");
        System.out.println("2.\t\tRoughneck\tHoodie");
        System.out.println("3.\t\tDenim\t\tColorbox crop ");
        System.out.println("4.\t\tCardinal\tSlim fit");
        System.out.println("================================================");
        try{
        pilih = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (pilih) {
            case 1:
                harga = 300000;
                setNamaPakaian("Dream Birds\tZipper");
                setEdisi("2018");
                setBahan("Fleece");
                ukuranJaketWanita();
                break;

            case 2:
                harga = 500000;
                setNamaPakaian("Roughneck\tHoodie");
                setEdisi("2020");
                setBahan("Taslan");
                ukuranJaketWanita();
                break;
            case 3:
                harga = 450000;
                setNamaPakaian("Denim\tColorbox Crop");
                setEdisi("2019");
                setBahan("Baby Terry");
                ukuranJaketWanita();
                break;
            case 4:
                harga = 750000;
                setNamaPakaian("Cardinal\tSlim fit");
                setEdisi("2020");
                setBahan("Parasut");
                ukuranJaketWanita();
                break;
        }
        }while(pilih<=0 || pilih>4);
    }

    public void ukuranJaketWanita() {
        do{
        System.out.println("================================================================================================");
        System.out.println(";No.\tUkuran\t    Panjang jaket\tLebar jaket\tPanjang Tangan\t Estimasi Berat Badan   ");
        System.out.println("------------------------------------------------------------------------------------------------");
        System.out.println("1.\tS\t\t64 cm\t\t41 cm\t\t58 cm\t\t\t30-49 kg");
        System.out.println("2.\tM\t\t64 cm\t\t43 cm\t\t58 cm\t\t\t50-60 kg");
        System.out.println("3.\tL\t\t66 cm\t\t44 cm\t\t59 cm\t\t\t55-75 kg");
        System.out.println("4.\tXL\t\t66 cm\t\t46 cm\t\t59 cm\t\t\t65-90 kg");
        System.out.println("5.\tXXL\t\t68 cm\t\t47 cm\t\t60 cm\t\t\t70-90 kg");
        System.out.println("================================================================================================");
        try{
        size = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 4:
                harga = harga + 7000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                harga = harga + 11000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(size<=0 || size>5);
    }

    public void daftarBajuAnakAnak() {
        do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis baju ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tCarter's\tT-shirt ");
        System.out.println("2.\t\tGAP kids\tKaos lengan panjang");
        System.out.println("3.\t\tHush Puppies\tpiyama");
        System.out.println("4.\t\tGymboree\tKemeja");
        System.out.println("================================================");
        try{
        pilih = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (pilih) {
            case 1:
                setHarga(120000);
                setNamaPakaian("Carter's\tT-shirt");
                setEdisi("2018");
                setBahan("Minky");
                ukuranBajuAnakAnak();
                break;

            case 2:
                harga = 50000;
                setNamaPakaian("GAP Kids\tKaos Lengan Panjang");
                setEdisi("2020");
                setBahan("Katun Kombed");
                ukuranBajuAnakAnak();
                break;
            case 3:
                harga = 100000;
                setNamaPakaian("Hush Puppies\tPiyama");
                setEdisi("2019");
                setBahan("Katun Viscose");
                ukuranBajuAnakAnak();
                break;
            case 4:
                harga = 200000;
                setNamaPakaian("Gymboree\tKemeja");
                setEdisi("2021");
                setBahan("Linen");
                ukuranBajuAnakAnak();
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(pilih<=0 || pilih>4);
    }

    public void ukuranBajuAnakAnak() {
       do{
        System.out.println("================================================");
        System.out.println("No.\tUkuran\t\tPanjang\t\tLebar   ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\tS\t\t34 cm\t\t42 cm");
        System.out.println("2.\tM\t\t36 cm\t\t49 cm");
        System.out.println("3.\tL\t\t39 cm\t\t52 cm");
        System.out.println("4.\tXL\t\t42 cm\t\t55 cm");
        System.out.println("5.\tXXL\t\t44 cm\t\t58 cm");
        System.out.println("================================================");
        try{
        size = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");

                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 4:
                harga = harga + 4000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                harga = harga + 6000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
       }while(size<=0 || size>5);
    }

    public void daftarCelanaAnakAnak() {
        do{
        System.out.println("================================================");
        System.out.println("No.\t\tMerk\t\tJenis Celana ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\t\tBohoBaby\tovertee pants ");
        System.out.println("2.\t\tPolo\t\tLegging");
        System.out.println("3.\t\tOvikids \tCelana Kulot");
        System.out.println("4.\t\tArdenleon\tShort Chino");
        System.out.println("================================================");
        try{
        pilih = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (pilih) {
            case 1:
                harga = 40000;
                setNamaPakaian("BohoBaby\tOvertee Pants");
                setEdisi("2018");
                setBahan("Satin");
                ukuranCelanaAnakAnak();
                break;

            case 2:
                harga = 130000;
                setNamaPakaian("Polo\tLegging");
                setEdisi("2020");
                setBahan("Wol");
                ukuranCelanaAnakAnak();
                break;
            case 3:
                harga = 95000;
                setNamaPakaian("Ovikids\tCelana Kulot");
                setEdisi("2021");
                setBahan("Katun");
                ukuranCelanaAnakAnak();
                break;
            case 4:
                harga = 55000;
                setNamaPakaian("Ardenleon\tShort Chino");
                setEdisi("2023");
                setBahan("Linen");
                ukuranCelanaAnakAnak();
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(pilih<=0 || pilih>4);
    }

    public void ukuranCelanaAnakAnak() {
        do{
        System.out.println("================================================");
        System.out.println("No.\tUkuran\tPinggang\tPanjang kaki   ");
        System.out.println("------------------------------------------------");
        System.out.println("1.\tS\t38 cm\t\t65 cm");
        System.out.println("2.\tM\t40 cm\t\t67 cm");
        System.out.println("3.\tL\t42 cm\t\t71 cm");
        System.out.println("4.\tXL\t54 cm\t\t74 cm");
        System.out.println("5.\tXXL\t66 cm\t\t76 cm");
        System.out.println("================================================");
        try{
        size = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 3:
                System.out.println(harga);
                break;
            case 4:
                harga = harga + 6000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                harga = harga + 8000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(size<=0 || size>5);

    }

    public void daftarJaketAnakAnak() {
        do{
        System.out.println("=================================================");
        System.out.println("No.\t\tMerk\t\t  Jenis Jaket");
        System.out.println("-------------------------------------------------");
        System.out.println("1.\t\tPop Kids\tBunny ear hoodie ");
        System.out.println("2.\t\tGummyBaby\tJaket zipper");
        System.out.println("3.\t\tBrooklyn\tSweater");
        System.out.println("4.\t\tUnisex  \tJaket jeans");
        System.out.println("=================================================");
        try{
        pilih = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (pilih) {
            case 1:
                harga = 185000;
                setNamaPakaian("Pop Kids\tBunny Ear Hoodie");
                setEdisi("2018");
                setBahan("Linen");
                ukuranJaketAnakAnak();
                break;

            case 2:
                harga = 65000;
                setNamaPakaian("GummyBaby\tJAket Zipper");
                setEdisi("2019");
                setBahan("Baby Terry");
                ukuranJaketAnakAnak();
                break;
            case 3:
                harga = 250000;
                setNamaPakaian("Brooklyn\tSweater");
                setEdisi("2020");
                setBahan("Fleece");
                ukuranJaketAnakAnak();
                break;
            case 4:
                harga = 400000;
                setNamaPakaian("Unisex\tJaket Jeans");
                setEdisi("2021");
                setBahan("Polyester");
                ukuranJaketAnakAnak();
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(pilih<=0 || pilih>4);
    }

    public void ukuranJaketAnakAnak() {
        do{
        System.out.println("==============================================================================================");
        System.out.println("No.\tUkuran\tPanjang jaket\tLebar jaket\tPanjang Tangan\tEstimasi Umur   ");
        System.out.println("----------------------------------------------------------------------------------------------");
        System.out.println("1.\tS\t 46 cm\t\t76 cm\t\t38 cm\t\t  2-3 ");
        System.out.println("2.\tM\t 48 cm\t\t80 cm\t\t40 cm\t\t  3-4 ");
        System.out.println("3.\tL\t 50 cm\t\t84 cm\t\t42 cm\t\t  4-5 ");
        System.out.println("4.\tXL\t 52 cm\t\t88 cm\t\t44 cm\t\t  6-7 ");
        System.out.println("5.\tXXL\t 54 cm\t\t92 cm\t\t46 cm\t\t  7-8 ");
        System.out.println("================================================================================================");
        try{
        size = scan.nextInt();
        } catch (InputMismatchException e)
            {
                System.out.println("Input tidak valid, input menggunakan urutan nomor.");
                scan.nextLine(); // Membersihkan buffer masukan
            }
        switch (size) {
            case 1:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 2:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 3:
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 4:
                harga = harga + 8000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
            case 5:
                harga = harga + 10000;
                System.out.println("--------------------------------------------");
                System.out.println("Nama Pakaian = " + getNamaPakaian());
                System.out.println("Edisi        = " + getEdisi());
                System.out.println("Jenis Bahan  = " + getBahan());
                System.out.println("Harga barang = " + getHarga());
                System.out.println("--------------------------------------------");
                break;
                default:
                System.out.println("Pilihan tidak tersedia, coba lagi");
        }
        }while(size<=0 || size>5);
    }

}