/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kelompok_PBOL;

/**
 *
 * @author LENOVO
 */
public class TanamanPadi extends Tanaman {
    
        
    public TanamanPadi(){
        
    }
    

    public TanamanPadi(String namaTanaman, int hargaTanaman, int stokTanaman) {
        super(namaTanaman, hargaTanaman, stokTanaman);
    }

    @Override
    public void setStokTanaman() {
        super.setStokTanaman(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int getStokTanaman() {
        return super.getStokTanaman(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setHargaTanaman(int hargaTanaman) {
        super.setHargaTanaman(hargaTanaman); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int getHargaTanaman() {
        return super.getHargaTanaman(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setNamaTanaman(String namaTanaman) {
        super.setNamaTanaman(namaTanaman); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getNamaTanaman() {
        return super.getNamaTanaman(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

}

