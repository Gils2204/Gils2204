/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kelompok_PBOL;

/**
 *
 * @author ASUS
 */
public class Pembeli {

    private String namaPembeli, passwordPembeli, alamatPembeli, emailPembeli;

    public Pembeli() {

    }

    public String getPasswordPembeli() {
        return passwordPembeli;
    }

    public void setPasswordPembeli(String passwordPembeli) {
        this.passwordPembeli = passwordPembeli;
    }

    public String getAlamatPembeli() {
        return alamatPembeli;
    }

    public void setAlamatPembeli(String alamatPembeli) {
        this.alamatPembeli = alamatPembeli;
    }

    public String getEmailPembeli() {
        return emailPembeli;
    }

    public void setEmailPembeli(String emailPembeli) {
        this.emailPembeli = emailPembeli;
    }

    public String getNamaPembeli() {
        return namaPembeli;
    }

    public void setNamaPembeli(String namaPembeli) {
        this.namaPembeli = namaPembeli;
    }
}
