/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kelompok_PBOL;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class DataTanaman {

    ArrayList<Tanaman> listTanaman = new ArrayList();

    public DataTanaman() {
        listTanaman.add(new TanamanPakis("Tanaman Pakis ", 45000, 200));
        listTanaman.add(new TanamanBonsai("Tanaman Bonsai", 1000000, 10));
        listTanaman.add(new TanamanLidahBuaya("Tanaman Lidah Buaya", 20000, 100));
        listTanaman.add(new TanamanLidahMertua("Tanaman Lidah Mertua", 12500, 100));
        listTanaman.add(new TanamanWijayaKusuma("Tanaman Wijaya Kusuma", 54000, 100));
        listTanaman.add(new TanamanJahe("Tanaman Jahe",10000,50));
        listTanaman.add(new TanamanKunyit("Tanaman Kunyit",15000,70));
        listTanaman.add(new TanamanPadi("Tanaman Padi",8000,1000));
        listTanaman.add(new TanamanUbiJalar("Tanaman Ubi Jalar",25000,100));
        listTanaman.add(new TanamanWisteria("Tanaman Wisteria",500000,50));
    
        
    }

    public ArrayList<Tanaman> getListTanaman() {
        return listTanaman;
    }

    public void setListTanaman(ArrayList<Tanaman> listTanaman) {
        this.listTanaman = listTanaman;
    }
}
