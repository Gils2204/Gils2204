/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kelompok_PBOL;

/**
 *
 * @author ASUS
 */
public class TanamanPakis extends Tanaman {
    
    public TanamanPakis(){
        
    }
    
    public TanamanPakis(String namaTanaman, int hargaTanaman, int stokTanaman) {
        super(namaTanaman, hargaTanaman, stokTanaman);
    }

    @Override
    public void setStokTanaman() {
        super.setStokTanaman(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int getStokTanaman() {
        return super.getStokTanaman(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setHargaTanaman(int hargaTanaman) {
        super.setHargaTanaman(hargaTanaman); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public int getHargaTanaman() {
        return super.getHargaTanaman(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public void setNamaTanaman(String namaTanaman) {
        super.setNamaTanaman(namaTanaman); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    @Override
    public String getNamaTanaman() {
        return super.getNamaTanaman(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }   
}